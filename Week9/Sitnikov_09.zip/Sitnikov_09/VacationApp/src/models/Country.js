// src/models/Country.js
class Country {
  constructor(id, name, color, imageUrl) {
    this.id = id;
    this.name = name;
    this.color = color;
    this.imageUrl = imageUrl;
  }
}

export default Country;
